#ifndef SIN_VALUE_H
#define SIN_VAULE_H
void sin_value(float sin_angle);
#endif
