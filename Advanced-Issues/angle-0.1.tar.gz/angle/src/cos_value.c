#include <stdio.h>
#include <math.h>

void cos_value(float cos_angle)
{
    float value;
    value = cos(cos_angle);
    printf ("The COS value for %5.2f is: %5.2f\n", cos_angle, value);
}
