#include <stdio.h>
#include <math.h>

void sin_value(float sin_angle)
{
    float value;
    value = sin(sin_angle);
    printf("\nThe SIN value for %5.2f is: %5.2f\n", sin_angle, value);
}
