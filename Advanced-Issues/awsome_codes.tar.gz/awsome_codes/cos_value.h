#ifndef SIN_VALUE_H
#define SIN_VAULE_H
void cos_value(float cos_angle);
#endif
