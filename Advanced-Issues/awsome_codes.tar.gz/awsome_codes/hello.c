#include <stdio.h>

int hello(char name[15])
{
    printf ("\n\nHi, Dear %s, nice to meet you.", name);
}
