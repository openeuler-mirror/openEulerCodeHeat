#include <stdio.h>
#include <math.h>

void sin_value(float sin_angle)
{
    float value;
    value = sin(sin_angle);
    printf("\nThe Sin is: %5.2f\n",value);
}
